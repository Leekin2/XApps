# Shared by customize.sh and service.sh: install the bundled XApps app (when this zip carries it)
# and enable it in LSPosed with its whole scope. Prints one line per step.
XAPPS_PKG=io.github.leekin2.xapps
LSPD_DB=/data/adb/lspd/config/modules_config.db
# The separate modules XApps replaces; XReply was merged into XNotify 4.0.
OLD_APPS="io.github.leekin2.xgoogle io.github.leekin2.xsecurity io.github.leekin2.xnotify io.github.leekin2.xreply"

# Copies an old app's own settings file under the name XApps uses, unless XApps has one already.
copy_prefs() {
  src=/data/data/$1/shared_prefs/$2.xml
  dir=/data/data/$XAPPS_PKG/shared_prefs
  dst=$dir/$3.xml
  [ -f "$src" ] && [ ! -f "$dst" ] || return 0
  uid=$(stat -c %u "/data/data/$XAPPS_PKG") || return 1
  # The app's own label, with its per-app categories (restorecon leaves those out).
  ctx=$(/system/bin/ls -dZ "/data/data/$XAPPS_PKG") || return 1
  ctx=${ctx%% *}
  mkdir -p "$dir" && chown "$uid:$uid" "$dir" && chmod 771 "$dir" && chcon "$ctx" "$dir" || return 1
  if ! { cp -f "$src" "$dst" && chown "$uid:$uid" "$dst" && chmod 660 "$dst" && chcon "$ctx" "$dst"; }; then
    rm -f "$dst"
    return 1
  fi
  echo "settings: copied $1 $2"
}

# Old XGoogle / XSecurity / XNotify / XReply apps: their settings come over first. Prints the apps
# whose settings could not be copied: they stay installed (uninstalling would lose the settings for
# good) and are switched off in LSPosed instead, so they never hook next to XApps.
copy_old_settings() {
  for pkg in $OLD_APPS; do
    pm path "$pkg" > /dev/null 2>&1 || continue
    am force-stop "$pkg" 2>/dev/null
    copied=true
    case "$pkg" in
      *.xgoogle) copy_prefs "$pkg" xgoogle_ui xgoogle_ui > /dev/null || copied=false ;;
      *.xsecurity)
        copy_prefs "$pkg" switches xsecurity_switches > /dev/null || copied=false
        copy_prefs "$pkg" ui xsecurity_ui > /dev/null || copied=false ;;
    esac
    [ "$copied" = true ] || echo "$pkg"
  done
}

# Uninstalls the old apps, except those given as arguments.
# $1: "off" when the kept apps were switched off in LSPosed, "kept" otherwise; then the kept apps.
retire_old_apps() {
  mode=$1; shift
  for pkg in $OLD_APPS; do
    pm path "$pkg" > /dev/null 2>&1 || continue
    case " $* " in
      *" $pkg "*)
        if [ "$mode" = off ]; then
          echo "old app: $pkg kept and switched off in LSPosed, its settings could not be copied. Uninstall it by hand"
        else
          echo "old app: $pkg kept, its settings could not be copied. Switch it off in LSPosed and uninstall it by hand"
        fi
        continue ;;
    esac
    if pm uninstall "$pkg" > /dev/null 2>&1; then echo "old app: $pkg uninstalled"; else echo "old app: $pkg could not be uninstalled, remove it by hand"; fi
  done
}

xapps_setup() {
  apk_src="$1"
  tmp=/data/local/tmp/xapps-setup
  rm -rf "$tmp"; mkdir -p "$tmp"
  if [ -f "$apk_src" ]; then
    cp -f "$apk_src" "$tmp/xapps.apk"; chmod 644 "$tmp/xapps.apk"
    if ! out=$(pm install -r "$tmp/xapps.apk" 2>&1); then
      echo "app: install failed: $out"
      case "$out" in *SIGNATURES*|*UPDATE_INCOMPATIBLE*) echo "app: uninstall the XApps app first, then flash again" ;; esac
      rm -rf "$tmp"; return 1
    fi
    echo "app: installed"
  fi
  apk=$(pm path "$XAPPS_PKG" 2>/dev/null | grep base.apk | head -1 | sed 's/^package://')
  if [ -z "$apk" ]; then
    echo "app: not installed"
    rm -rf "$tmp"; return 1
  fi
  if [ ! -f "$LSPD_DB" ]; then
    echo "lsposed: not found, install LSPosed and enable XApps there"
    rm -rf "$tmp"; retire_old_apps kept $(copy_old_settings); return 0
  fi
  pm list packages > "$tmp/packages.txt"
  kept=$(copy_old_settings)
  # Before the old apps go: uninstalling one drops its LSPosed settings.
  res=$(app_process -Djava.class.path="$apk" /system/bin io.github.leekin2.xapps.ScopeWriter "$LSPD_DB" "$apk" 0 "$tmp/packages.txt" $OLD_APPS --disable $kept 2>"$tmp/scope.err" | tail -n 1)
  err=$(tail -n 3 "$tmp/scope.err" 2>/dev/null | tr '
' ' ')
  rm -rf "$tmp"
  case "$res" in
    ok*)
      set -- $res
      echo "lsposed: enabled, scope ticked ($2 new), old settings copied ($3)"
      retire_old_apps off $kept
      ;;
    *)
      echo "lsposed: could not write (${res:-no answer}${err:+; $err}), enable XApps and tick its scope in LSPosed"
      for pkg in $OLD_APPS; do
        pm path "$pkg" > /dev/null 2>&1 && echo "old app: $pkg kept, its LSPosed settings were not copied. Uninstall it by hand"
      done
      ;;
  esac
  return 0
}
